document.addEventListener("DOMContentLoaded", function() {
  let slides = document.querySelectorAll('#mySlides .slide');
  let currentSlide = 0;

  // Masquer toutes les diapositives sauf la première
  for (let i = 1; i < slides.length; i++) {
      slides[i].style.display = 'none';
  }

  // Fonction pour passer à la prochaine diapositive
  function nextSlide() {
      slides[currentSlide].style.display = 'none';
      currentSlide = (currentSlide + 1) % slides.length;
      slides[currentSlide].style.display = 'block';
  }

  // Appeler nextSlide toutes les 3 secondes
  setInterval(nextSlide, 3000);
});

function togglePost(post) {
  post.classList.toggle('open');
  const details = post.querySelector('.post-details');
  if (details.style.display === 'block' || details.style.display === '') {
      details.style.display = 'none';
  } else {
      details.style.display = 'block';
  }
}