# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1716198411.442158
_enable_loop = True
_template_filename = 'ressources/templates/suppressionJoueur.html'
_template_uri = 'suppressionJoueur.html'
_source_encoding = 'utf-8'
_exports = []


def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, 'template.html', _template_uri)
def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        joueurs = context.get('joueurs', UNDEFINED)
        message = context.get('message', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('\r\n\r\n<div class="suppression-container">\r\n    <h3 class="center">Suppression d\'un joueur</h3>\r\n\r\n    <form action="suppressionJoueur" method="post" class="suppression-form">\r\n        <div class="form-group">\r\n            <label for="idJoueur">Sélectionnez un joueur à supprimer :</label>\r\n            <select id="idJoueur" name="idJoueur">\r\n')
        for joueur in joueurs:
            __M_writer('                    <option value="')
            __M_writer(str(joueur[0]))
            __M_writer('">')
            __M_writer(str(joueur[1]))
            __M_writer(' ')
            __M_writer(str(joueur[2]))
            __M_writer('</option>\r\n')
        __M_writer('            </select>\r\n        </div>\r\n        <button type="submit" class="submit-button">Supprimer</button>\r\n    </form>\r\n\r\n')
        if message:
            __M_writer('        <div class="message">\r\n            <p>')
            __M_writer(str(message))
            __M_writer('</p>\r\n        </div>\r\n')
        __M_writer('</div>\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "ressources/templates/suppressionJoueur.html", "uri": "suppressionJoueur.html", "source_encoding": "utf-8", "line_map": {"27": 0, "34": 1, "35": 10, "36": 11, "37": 11, "38": 11, "39": 11, "40": 11, "41": 11, "42": 11, "43": 13, "44": 18, "45": 19, "46": 20, "47": 20, "48": 23, "54": 48}}
__M_END_METADATA
"""
