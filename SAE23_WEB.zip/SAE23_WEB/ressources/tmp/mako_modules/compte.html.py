# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1716208802.6352634
_enable_loop = True
_template_filename = 'ressources/templates/compte.html'
_template_uri = 'compte.html'
_source_encoding = 'utf-8'
_exports = []


def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, 'template.html', _template_uri)
def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        infosUtilisateur = context.get('infosUtilisateur', UNDEFINED)
        messageMdp = context.get('messageMdp', UNDEFINED)
        places = context.get('places', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('\r\n\r\n<div class="container">\r\n    <h2 class="account-title">Mon Compte</h2>\r\n\r\n    <!-- Affichage des informations utilisateur -->\r\n    <div class="user-info">\r\n        <h3>Informations personnelles</h3>\r\n        <p>Prénom: ')
        __M_writer(str(infosUtilisateur[0][1]))
        __M_writer('</p>\r\n        <p>Nom: ')
        __M_writer(str(infosUtilisateur[0][2]))
        __M_writer('</p>\r\n        <p>Mail: ')
        __M_writer(str(infosUtilisateur[0][4]))
        __M_writer('</p>\r\n        <p>Pseudo: ')
        __M_writer(str(infosUtilisateur[0][3]))
        __M_writer('</p>\r\n    </div>\r\n\r\n    <!-- Formulaire de modification du mot de passe -->\r\n    <div class="password-form">\r\n        <h3>Changer de mot de passe</h3>\r\n        <form action="nouvMdp" method="post">\r\n            <label for="ancienMdp">Ancien mot de passe:</label>\r\n            <input type="password" id="ancienMdp" name="ancienMdp" required>\r\n            <label for="nouvMdp">Nouveau mot de passe:</label>\r\n            <input type="password" id="nouvMdp" name="nouvMdp" required>\r\n            <label for="confirmerMdp">Confirmer le nouveau mot de passe:</label>\r\n            <input type="password" id="confirmerMdp" name="confirmerMdp" required>\r\n            <button type="submit">Changer le mot de passe</button>\r\n        </form>\r\n    </div>\r\n')
        if messageMdp:
            __M_writer('        <p>')
            __M_writer(str(messageMdp))
            __M_writer('</p>\r\n')
        __M_writer('\r\n    <div class="tickets">\r\n        <h3>Billets achetés</h3>\r\n')
        if places :
            pass
            for infos in places:
                __M_writer('                <div class="billet">\r\n                    <div class="billet-details">\r\n                        <p>Numéro de la catégorie : ')
                __M_writer(str(infos[0]))
                __M_writer('</p>\r\n                        <p>Virage : ')
                __M_writer(str(infos[1]))
                __M_writer('</p>\r\n                        <p>Prix : ')
                __M_writer(str(infos[2]))
                __M_writer('€</p>\r\n                    </div>\r\n                </div>\r\n')
        else:
            __M_writer('            <p>Aucun billet acheté.</p>\r\n')
        __M_writer('    </div>\r\n    <form action="deconnexion" method="post">\r\n        <button type="submit">Se déconnecter</button>\r\n    </form>\r\n</div>\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "ressources/templates/compte.html", "uri": "compte.html", "source_encoding": "utf-8", "line_map": {"27": 0, "35": 1, "36": 9, "37": 9, "38": 10, "39": 10, "40": 11, "41": 11, "42": 12, "43": 12, "44": 28, "45": 29, "46": 29, "47": 29, "48": 31, "49": 34, "51": 35, "52": 36, "53": 38, "54": 38, "55": 39, "56": 39, "57": 40, "58": 40, "59": 44, "60": 45, "61": 47, "67": 61}}
__M_END_METADATA
"""
