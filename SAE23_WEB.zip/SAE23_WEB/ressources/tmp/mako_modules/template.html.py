# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1716119131.4044437
_enable_loop = True
_template_filename = 'ressources/templates/template.html'
_template_uri = 'template.html'
_source_encoding = 'utf-8'
_exports = []


def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        self = context.get('self', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('<!DOCTYPE html>\r\n<html lang="fr">\r\n<head>\r\n    <meta charset="UTF-8">\r\n    <title>OMStats</title>\r\n    <link rel="stylesheet" type="text/css" href="/static/css/template.css">\r\n    <script src="/static/js/scripts.js" defer></script>\r\n</head>\r\n<body>\r\n    <ul class="navbar">\r\n        <li><a href="index">Accueil</a></li>\r\n        <li><a href="saison">Saison</a></li>\r\n        <li><a href="joueurs">Joueurs</a></li>\r\n        <li><a href="billetterie">Billetterie</a></li>\r\n        <li><a href="compte">Mon compte</a></li>\r\n    </ul>\r\n    \r\n    ')
        __M_writer(str( self.body() ))
        __M_writer('\r\n</body>\r\n</html>\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "ressources/templates/template.html", "uri": "template.html", "source_encoding": "utf-8", "line_map": {"16": 0, "22": 1, "23": 18, "24": 18, "30": 24}}
__M_END_METADATA
"""
