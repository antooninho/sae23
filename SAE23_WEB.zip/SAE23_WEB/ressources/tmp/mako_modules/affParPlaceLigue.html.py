# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1716196346.2436602
_enable_loop = True
_template_filename = 'ressources/templates/affParPlaceLigue.html'
_template_uri = 'affParPlaceLigue.html'
_source_encoding = 'utf-8'
_exports = []


def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, 'template.html', _template_uri)
def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        annees = context.get('annees', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('\r\n\r\n<div class="statistiques-container">\r\n')
        for e in annees:
            __M_writer('        <div class="statistique-post" onclick="togglePost(this)">\r\n            <h4>')
            __M_writer(str(e[1]))
            __M_writer('</h4>\r\n            <div class="post-details">\r\n                \r\n                <p>Meilleur joueur : ')
            __M_writer(str(e[2]))
            __M_writer('</p>\r\n                <p>Parcours en coupe européenne : ')
            __M_writer(str(e[3]))
            __M_writer('</p>\r\n                <p>Place en ligue : ')
            __M_writer(str(e[4]))
            __M_writer('</p>\r\n            </div>\r\n        </div>\r\n')
        __M_writer('</div>\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "ressources/templates/affParPlaceLigue.html", "uri": "affParPlaceLigue.html", "source_encoding": "utf-8", "line_map": {"27": 0, "33": 1, "34": 4, "35": 5, "36": 6, "37": 6, "38": 9, "39": 9, "40": 10, "41": 10, "42": 11, "43": 11, "44": 15, "50": 44}}
__M_END_METADATA
"""
