# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1716310675.1861644
_enable_loop = True
_template_filename = 'ressources/templates/match.html'
_template_uri = 'match.html'
_source_encoding = 'utf-8'
_exports = []


def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, 'template.html', _template_uri)
def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        message = context.get('message', UNDEFINED)
        places = context.get('places', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('\r\n<link rel="stylesheet" type="text/css" href="/static/css/match.css">\r\n\r\n<div class="match-container">\r\n    <h2>Choisissez votre place</h2>\r\n    <form method="get" action="match" class="match-form">\r\n        <label for="categorie">Catégorie:</label>\r\n        <select name="categorie" id="categorie">\r\n            <option value="1">1</option>\r\n            <option value="2">2</option>\r\n            <option value="3">3</option>\r\n            <option value="4">4</option>\r\n            <option value="5">5</option>\r\n        </select>\r\n        <label for="virage">Virage:</label>\r\n        <select name="virage" id="virage">\r\n            <option value="sud">Sud</option>\r\n            <option value="est">Est</option>\r\n            <option value="ouest">Ouest</option>\r\n            <option value="nord">Nord</option>\r\n        </select>\r\n        <input type="submit" value="Afficher les places">\r\n    </form>\r\n\r\n')
        if places :
            __M_writer('        <h2>Places disponibles</h2>\r\n        <table class="match-table">\r\n            <thead>\r\n                <tr>\r\n                    <th>Catégorie</th>\r\n                    <th>Virage</th>\r\n                    <th>Prix</th>\r\n                    <th>Places disponibles</th>\r\n                    <th>Action</th>\r\n                </tr>\r\n            </thead>\r\n            <tbody>\r\n')
            for place in places :
                __M_writer('                    <tr>\r\n                        <td>')
                __M_writer(str( place[1] ))
                __M_writer('</td>\r\n                        <td>')
                __M_writer(str( place[2] ))
                __M_writer('</td>\r\n                        <td>')
                __M_writer(str( place[3] ))
                __M_writer('€</td>\r\n                        <td>')
                __M_writer(str( place[4] ))
                __M_writer('</td>\r\n                        <td>\r\n')
                if place[4] > 0:
                    __M_writer('                                <form method="post" action="acheter" class="purchase-form">\r\n                                    <input type="hidden" name="idPlace" value="')
                    __M_writer(str( place[0] ))
                    __M_writer('">\r\n                                    <input type="submit" value="Acheter">\r\n                                </form>\r\n')
                else:
                    __M_writer('                                <span>Indisponible</span>\r\n')
                __M_writer('                        </td>\r\n                    </tr>\r\n')
            __M_writer('            </tbody>\r\n        </table>\r\n')
        __M_writer('\r\n')
        if message:
            __M_writer('        <p class="message">')
            __M_writer(str(message))
            __M_writer('</p>\r\n')
        __M_writer('</div>\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "ressources/templates/match.html", "uri": "match.html", "source_encoding": "utf-8", "line_map": {"27": 0, "34": 1, "35": 25, "36": 26, "37": 38, "38": 39, "39": 40, "40": 40, "41": 41, "42": 41, "43": 42, "44": 42, "45": 43, "46": 43, "47": 45, "48": 46, "49": 47, "50": 47, "51": 50, "52": 51, "53": 53, "54": 56, "55": 59, "56": 60, "57": 61, "58": 61, "59": 61, "60": 63, "66": 60}}
__M_END_METADATA
"""
