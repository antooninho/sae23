# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1716210748.8677902
_enable_loop = True
_template_filename = 'ressources/templates/joueurs.html'
_template_uri = 'joueurs.html'
_source_encoding = 'utf-8'
_exports = []


def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, 'template.html', _template_uri)
def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        admin = context.get('admin', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('\r\n\r\n\r\n</head>\r\n<body>\r\n<!-- Deuxième barre de navigation spécifique à la page "Saison" -->\r\n<div class="second-navbar">\r\n    <div class="dropdown">\r\n        <button class="dropbtn">Affichages \r\n            <i class="fa fa-caret-down"></i>\r\n          </button>\r\n          <div class="dropdown-contenu">\r\n            <a href="affParNom">Afficher par ordre alphabétique (nom)</a>\r\n            <a href="affParTrancheAge">Afficher par tranche d\'âge</a>\r\n            <a href="affParTranchePrix">Afficher par tranche prix</a>\r\n            <a href="affParPrix">Afficher par prix</a>\r\n            <a href="affParPoste">Afficher par poste</a>\r\n          </div>\r\n    </div>\r\n')
        if admin :
            __M_writer('      <div class="dropdown">\r\n          <button class="dropbtn">Insertion \r\n              <i class="fa fa-caret-down"></i>\r\n            </button>\r\n            <div class="dropdown-contenu">\r\n              <a href="insertionJoueur">Insérer un joueur</a>\r\n              \r\n            </div>\r\n      </div>\r\n      <div class="dropdown">\r\n        <button class="dropbtn">Suppression \r\n          <i class="fa fa-caret-down"></i>\r\n        </button>\r\n        <div class="dropdown-contenu">\r\n          <a href="suppressionJoueur">Par nom</a>\r\n        </div>\r\n      </div> \r\n')
        __M_writer('  </div>\r\n\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "ressources/templates/joueurs.html", "uri": "joueurs.html", "source_encoding": "utf-8", "line_map": {"27": 0, "33": 1, "34": 20, "35": 21, "36": 39, "42": 36}}
__M_END_METADATA
"""
