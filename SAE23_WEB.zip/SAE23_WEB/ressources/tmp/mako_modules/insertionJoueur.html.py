# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1716198329.1471117
_enable_loop = True
_template_filename = 'ressources/templates/insertionJoueur.html'
_template_uri = 'insertionJoueur.html'
_source_encoding = 'utf-8'
_exports = []


def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, 'template.html', _template_uri)
def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        message = context.get('message', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('\r\n\r\n<link rel="stylesheet" type="text/css" href="/static/css/insertion.css">\r\n\r\n<div class="insertion-container">\r\n    <h3 class="center">Insertion d\'un nouveau joueur</h3>\r\n\r\n    <form action="insertionJoueur" method="post" class="insertion-form">\r\n        <div class="form-group">\r\n            <label for="prenom">Prénom :</label>\r\n            <input type="text" id="prenom" name="prenom" required>\r\n        </div>\r\n        <div class="form-group">\r\n            <label for="nom">Nom :</label>\r\n            <input type="text" id="nom" name="nom" required>\r\n        </div>\r\n        <div class="form-group">\r\n            <label for="age">Âge actuel :</label>\r\n            <input type="number" id="age" name="age" required>\r\n        </div>\r\n        <div class="form-group">\r\n            <label for="prix">Prix d\'achat :</label>\r\n            <input type="number" id="prix" name="prix" required>\r\n        </div>\r\n        <div class="form-group">\r\n            <label for="dateNaissance">Date de naissance :</label>\r\n            <input type="date" id="dateNaissance" name="dateNaissance" required>\r\n        </div>\r\n        <div class="form-group">\r\n            <label for="poste">Poste :</label>\r\n            <select id="poste" name="poste" required>\r\n                <option value="attaquant">Attaquant</option>\r\n                <option value="gardien">Gardien</option>\r\n                <option value="défenseur">Défenseur</option>\r\n                <option value="milieu">Milieu</option>\r\n            </select>\r\n        </div>\r\n        <button type="submit" class="submit-button">Ajouter</button>\r\n    </form>\r\n\r\n')
        if message:
            __M_writer('        <div class="message">\r\n            <p>')
            __M_writer(str(message))
            __M_writer('</p>\r\n        </div>\r\n')
        __M_writer('</div>\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "ressources/templates/insertionJoueur.html", "uri": "insertionJoueur.html", "source_encoding": "utf-8", "line_map": {"27": 0, "33": 1, "34": 41, "35": 42, "36": 43, "37": 43, "38": 46, "44": 38}}
__M_END_METADATA
"""
