# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1717164601.793437
_enable_loop = True
_template_filename = 'ressources/templates/index.html'
_template_uri = 'index.html'
_source_encoding = 'utf-8'
_exports = []


def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, 'template.html', _template_uri)
def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        matchs = context.get('matchs', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('\r\n<header>\r\n    <h1>Bienvenue sur OMStats</h1>\r\n</header>\r\n\r\n<section id="mySlides">\r\n    <img class="slide" src="/static/images/JPP.png" alt="Photo 1" >\r\n    <img class="slide" src="/static/images/30ans.jpg" alt="Photo 2">\r\n    <img class="slide" src="/static/images/qualif.jpg" alt="Photo 3">\r\n    <img class="slide" src="/static/images/aubameyang.jpg" alt="Photo 4">\r\n    <img class="slide" src="/static/images/1993.jpg" alt="Photo 5">\r\n</section>\r\n\r\n<section id="prochains-matchs">\r\n    <h2>Prochains matchs</h2>\r\n')
        for match in matchs:
            __M_writer('        <div class="prochain-match">\r\n            <img src="/static/images/logoOM.png" class="logo-gauche">\r\n            <h3>')
            __M_writer(str(match[1]))
            __M_writer(' vs ')
            __M_writer(str(match[2]))
            __M_writer('</h3>\r\n            <img src="/static/images/logoPSG.png" class="logo-droite">\r\n            <p>Date du match: ')
            __M_writer(str(match[3]))
            __M_writer('</p>\r\n            <p>Lieu du match: ')
            __M_writer(str(match[4]))
            __M_writer('</p>\r\n            <a href="match">Acheter des billets</a>\r\n        </div>\r\n')
        __M_writer('</section>\r\n\r\n<section id="palmares">\r\n    <h2>Palmarès</h2>\r\n    <!-- Conteneur pour les trophées avec défilement horizontal -->\r\n    <div class="trophees-container">\r\n        <!-- Liste de trophées -->\r\n        <div class="trophee">Ligue des Champions<br><span>1</span></div>\r\n        <div class="trophee">Championnat de France <br><span>11</span></div>\r\n        <div class="trophee">Championnat de France D2 <br><span>1</span></div>\r\n        <div class="trophee">Coupe de France <br><span>10</span></div>\r\n        <div class="trophee2">Coupe de la Ligue <br><span>3</span></div>\r\n        <div class="trophee2">Trophée des champions <br><span>3</span></div>\r\n        <div class="trophee2">Coupe Intertoto <br><span>1</span></div>\r\n    </div>\r\n</section>\r\n</br>\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "ressources/templates/index.html", "uri": "index.html", "source_encoding": "utf-8", "line_map": {"27": 0, "33": 1, "34": 16, "35": 17, "36": 19, "37": 19, "38": 19, "39": 19, "40": 21, "41": 21, "42": 22, "43": 22, "44": 26, "50": 44}}
__M_END_METADATA
"""
