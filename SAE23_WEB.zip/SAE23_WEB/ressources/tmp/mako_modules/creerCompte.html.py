# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1716206623.9611788
_enable_loop = True
_template_filename = 'ressources/templates/creerCompte.html'
_template_uri = 'creerCompte.html'
_source_encoding = 'utf-8'
_exports = []


def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, 'template.html', _template_uri)
def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        __M_writer = context.writer()
        __M_writer('\r\n\r\n<div class="create-account-container">\r\n    <h2>Créer un compte</h2>\r\n    <form action="creerCompte" method="post" class="create-account-form">\r\n        <div class="form-group">\r\n            <label for="prenom">Prénom :</label>\r\n            <input type="text" id="prenom" name="prenom" required>\r\n        </div>\r\n        <div class="form-group">\r\n            <label for="nom">Nom :</label>\r\n            <input type="text" id="nom" name="nom" required>\r\n        </div>\r\n        <div class="form-group">\r\n            <label for="pseudo">Pseudo :</label>\r\n            <input type="text" id="pseudo" name="pseudo" required>\r\n        </div>\r\n        <div class="form-group">\r\n            <label for="mail">Adresse e-mail :</label>\r\n            <input type="email" id="mail" name="mail" required>\r\n        </div>\r\n        <div class="form-group">\r\n            <label for="motDePasse">Mot de passe :</label>\r\n            <input type="password" id="motDePasse" name="motDePasse" required>\r\n        </div>\r\n        <button type="submit" class="submit-button">Créer un compte</button>\r\n    </form>\r\n</div>\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "ressources/templates/creerCompte.html", "uri": "creerCompte.html", "source_encoding": "utf-8", "line_map": {"27": 0, "32": 1, "38": 32}}
__M_END_METADATA
"""
