# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1716199646.9924035
_enable_loop = True
_template_filename = 'ressources/templates/affParNom.html'
_template_uri = 'affParNom.html'
_source_encoding = 'utf-8'
_exports = []


def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, 'template.html', _template_uri)
def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        joueurs = context.get('joueurs', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('\r\n\r\n<h3 class="center">Joueurs triés par ordre alphabétique</h3>\r\n\r\n<div class="statistiques-container">\r\n')
        for joueur in joueurs:
            __M_writer('        <div class="statistique-post" onclick="togglePost(this)">\r\n            <h4>')
            __M_writer(str(joueur[1]))
            __M_writer(' ')
            __M_writer(str(joueur[2]))
            __M_writer('</h4>\r\n            <div class="post-details">\r\n                \r\n                <p>Âge : ')
            __M_writer(str(joueur[3]))
            __M_writer("</p>\r\n                <p>Prix d'achat : ")
            __M_writer(str(joueur[4]))
            __M_writer('</p>\r\n                <p>Date de naissance : ')
            __M_writer(str(joueur[5]))
            __M_writer('</p>\r\n\t\t\t\t<p>Poste : ')
            __M_writer(str(joueur[6]))
            __M_writer('</p>\r\n            </div>\r\n        </div>\r\n')
        __M_writer('</div>\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "ressources/templates/affParNom.html", "uri": "affParNom.html", "source_encoding": "utf-8", "line_map": {"27": 0, "33": 1, "34": 6, "35": 7, "36": 8, "37": 8, "38": 8, "39": 8, "40": 11, "41": 11, "42": 12, "43": 12, "44": 13, "45": 13, "46": 14, "47": 14, "48": 18, "54": 48}}
__M_END_METADATA
"""
