# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1716214844.3975668
_enable_loop = True
_template_filename = 'ressources/templates/billetterie.html'
_template_uri = 'billetterie.html'
_source_encoding = 'utf-8'
_exports = []


def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, 'template.html', _template_uri)
def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        matchs = context.get('matchs', UNDEFINED)
        admin = context.get('admin', UNDEFINED)
        message = context.get('message', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('\r\n<section id="prochains-matchs">\r\n    <h2>Prochains matchs</h2>\r\n')
        for match in matchs:
            __M_writer('    <div class="prochain-match">\r\n        <img src="/static/images/logoOM.png" class="logo-gauche">\r\n        <h3>')
            __M_writer(str(match[1]))
            __M_writer(' vs ')
            __M_writer(str(match[2]))
            __M_writer('</h3>\r\n        <img src="/static/images/logoPSG.png" class="logo-droite">\r\n        <p>Date du match: ')
            __M_writer(str(match[3]))
            __M_writer('</p>\r\n        <p>Lieu du match: ')
            __M_writer(str(match[4]))
            __M_writer('</p>\r\n        <a href="match">Acheter des billets</a>\r\n    </div>\r\n')
        __M_writer('</section>\r\n\r\n')
        if admin :
            __M_writer('<div class="insertion-container">\r\n    <h3 class="center">Insertion d\'un nouveau match</h3>\r\n\r\n    <form action="insertionMatch" method="post" class="insertion-form">\r\n        <div class="form-group">\r\n            <label for="equipe_dom">Équipe domicile :</label>\r\n            <input type="text" id="equipe_dom" name="equipe_dom" required>\r\n        </div>\r\n        <div class="form-group">\r\n            <label for="equipe_ext">Équipe extérieure :</label>\r\n            <input type="text" id="equipe_ext" name="equipe_ext" required>\r\n        </div>\r\n        <div class="form-group">\r\n            <label for="date_match">Date du match :</label>\r\n            <input type="date" id="date_match" name="date_match" required>\r\n        </div>\r\n        <div class="form-group">\r\n            <label for="lieu">Lieu du match :</label>\r\n            <input type="text" id="lieu" name="lieu" required>\r\n        </div>\r\n        <button type="submit" class="submit-button">Ajouter</button>\r\n    </form>\r\n\r\n')
            if message:
                __M_writer('        <div class="message">\r\n            <p>')
                __M_writer(str(message))
                __M_writer('</p>\r\n        </div>\r\n')
            __M_writer('</div>\r\n\r\n\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "ressources/templates/billetterie.html", "uri": "billetterie.html", "source_encoding": "utf-8", "line_map": {"27": 0, "35": 1, "36": 4, "37": 5, "38": 7, "39": 7, "40": 7, "41": 7, "42": 9, "43": 9, "44": 10, "45": 10, "46": 14, "47": 16, "48": 17, "49": 40, "50": 41, "51": 42, "52": 42, "53": 45, "59": 53}}
__M_END_METADATA
"""
