# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1716201427.0217838
_enable_loop = True
_template_filename = 'ressources/templates/affParTrancheAge.html'
_template_uri = 'affParTrancheAge.html'
_source_encoding = 'utf-8'
_exports = []


def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, 'saison.html', _template_uri)
def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        joueurs = context.get('joueurs', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('\r\n\r\n<h3 class="center">Liste des joueurs par tranche d\'âge</h3>\r\n\r\n\r\n<form action="affParTrancheAge" method="get">\r\n    <label for="age_mini">Âge minimum :</label>\r\n    <input type="number" id="age_mini" name="age_mini" required>\r\n    <label for="age_maxi">Âge maximum :</label>\r\n    <input type="number" id="age_maxi" name="age_maxi" required>\r\n    <button type="submit">Afficher</button>\r\n</form>\r\n\r\n<div class="statistiques-container">\r\n')
        if joueurs:
            __M_writer('        <h4>Résultats :</h4>\r\n')
            for joueur in joueurs:
                __M_writer('            <div class="statistique-post" onclick="togglePost(this)">\r\n                <h4>')
                __M_writer(str(joueur[1]))
                __M_writer(' ')
                __M_writer(str(joueur[2]))
                __M_writer('</h4>\r\n                <div class="post-details">\r\n                    <p>Âge : ')
                __M_writer(str(joueur[3]))
                __M_writer("</p>\r\n                    <p>Prix d'achat : ")
                __M_writer(str(joueur[4]))
                __M_writer('</p>\r\n                    <p>Date de naissance : ')
                __M_writer(str(joueur[5]))
                __M_writer('</p>\r\n                    <p>Poste : ')
                __M_writer(str(joueur[6]))
                __M_writer('</p>\r\n                </div>\r\n            </div>\r\n')
        else:
            __M_writer("        <p>Aucun joueur trouvé pour cette tranche d'âge.</p>\r\n")
        __M_writer('</div>\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "ressources/templates/affParTrancheAge.html", "uri": "affParTrancheAge.html", "source_encoding": "utf-8", "line_map": {"27": 0, "33": 1, "34": 15, "35": 16, "36": 17, "37": 18, "38": 19, "39": 19, "40": 19, "41": 19, "42": 21, "43": 21, "44": 22, "45": 22, "46": 23, "47": 23, "48": 24, "49": 24, "50": 28, "51": 29, "52": 31, "58": 52}}
__M_END_METADATA
"""
