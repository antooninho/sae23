# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1716197084.7608747
_enable_loop = True
_template_filename = 'ressources/templates/suppressionSaison.html'
_template_uri = 'suppressionSaison.html'
_source_encoding = 'utf-8'
_exports = []


def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, 'template.html', _template_uri)
def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        message = context.get('message', UNDEFINED)
        saisons = context.get('saisons', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('\r\n\r\n<div class="suppression-container">\r\n    <h3 class="center">Suppression d\'une saison</h3>\r\n\r\n    <form action="suppressionSaison" method="post" class="suppression-form">\r\n        <div class="form-group">\r\n            <label for="idSaison">Sélectionnez une saison à supprimer :</label>\r\n            <select id="idSaison" name="idSaison">\r\n')
        for saison in saisons:
            __M_writer('                    <option value="')
            __M_writer(str(saison[0]))
            __M_writer('">')
            __M_writer(str(saison[1]))
            __M_writer('</option>\r\n')
        __M_writer('            </select>\r\n        </div>\r\n        <button type="submit" class="submit-button">Supprimer</button>\r\n    </form>\r\n\r\n')
        if message:
            __M_writer('        <div class="message">\r\n            <p>')
            __M_writer(str(message))
            __M_writer('</p>\r\n        </div>\r\n')
        __M_writer('</div>')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "ressources/templates/suppressionSaison.html", "uri": "suppressionSaison.html", "source_encoding": "utf-8", "line_map": {"27": 0, "34": 1, "35": 10, "36": 11, "37": 11, "38": 11, "39": 11, "40": 11, "41": 13, "42": 18, "43": 19, "44": 20, "45": 20, "46": 23, "52": 46}}
__M_END_METADATA
"""
