# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1716206375.7710013
_enable_loop = True
_template_filename = 'ressources/templates/login.html'
_template_uri = 'login.html'
_source_encoding = 'utf-8'
_exports = []


def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, 'template.html', _template_uri)
def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        message = context.get('message', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('\r\n\r\n<div class="login-container">\r\n    <h2>Connexion</h2>\r\n    <form action="login" method="post" class="login-form">\r\n        <div class="form-group">\r\n            <label for="pseudo">Pseudo :</label>\r\n            <input type="text" id="pseudo" name="pseudo" required>\r\n        </div>\r\n        <div class="form-group">\r\n            <label for="mdp">Mot de passe :</label>\r\n            <input type="password" id="mdp" name="mdp" required>\r\n        </div>\r\n        <button type="submit" class="submit-button">Se connecter</button>\r\n    </form>\r\n    \r\n    <!-- Affichage du message d\'erreur -->\r\n')
        if message:
            __M_writer('        <div class="message">\r\n            <p>')
            __M_writer(str(message))
            __M_writer('</p>\r\n        </div>\r\n')
        __M_writer('    \r\n    <!-- Lien vers la page de création de compte -->\r\n    <div class="create-account-link">\r\n        <p>Vous n\'avez pas de compte ? <a href="creerCompte">Créer un compte</a></p>\r\n    </div>\r\n</div>\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "ressources/templates/login.html", "uri": "login.html", "source_encoding": "utf-8", "line_map": {"27": 0, "33": 1, "34": 18, "35": 19, "36": 20, "37": 20, "38": 23, "44": 38}}
__M_END_METADATA
"""
