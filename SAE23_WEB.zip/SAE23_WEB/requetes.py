_requete= {
    "drop" : "DROP DATABASE IF EXISTS OMStats",
    "createBase" : "CREATE DATABASE IF NOT EXISTS OMStats DEFAULT CHARACTER SET utf8",
    "use" : "USE OMStats",
    "createJoueur": "CREATE TABLE joueur ( idJoueur INT(11) PRIMARY KEY AUTO_INCREMENT,\
                    prenom VARCHAR(20) NOT NULL,\
                    nom VARCHAR(20) NOT NULL,\
                    age INT(3) NOT NULL,\
                    prix INT(10) NOT NULL,\
                    dateNaissance DATE NOT NULL,\
                    poste ENUM ('défenseur', 'gardien', 'milieu', 'attaquant') NOT NULL);",

    "createSaison": "CREATE TABLE saison ( idSaison INT(11) PRIMARY KEY AUTO_INCREMENT,\
                    annees VARCHAR(9) NOT NULL,\
                    meilleurJoueur VARCHAR(40) NOT NULL,\
                    parcoursEurope VARCHAR(60) NOT NULL,\
                    placeLigue INT(2) NOT NULL);",

    "createTrophee": "CREATE TABLE trophee ( idTrophee INTEGER PRIMARY KEY AUTO_INCREMENT,\
                    nomTrophee VARCHAR(40) NOT NULL);",

    "createParticiper": "CREATE TABLE participer ( idSaison INT(11) NOT NULL,\
                        idJoueur INT(11) NOT NULL,\
                        FOREIGN KEY (idSaison) REFERENCES saison(idSaison) ON DELETE CASCADE,\
                        FOREIGN KEY (idJoueur) REFERENCES joueur(idJoueur) ON DELETE CASCADE);",

    "createGagner": "CREATE TABLE gagner( idTrophee INT(11) NOT NULL,\
                    idSaison INT(11) NOT NULL,\
                    FOREIGN KEY (idTrophee) REFERENCES trophee(idTrophee) ON DELETE CASCADE,\
                    FOREIGN KEY (idSaison) REFERENCES saison(idSaison) ON DELETE CASCADE);",

    "createPlace": "CREATE TABLE place ( idPlace INT(11) PRIMARY KEY AUTO_INCREMENT,\
                    nomCategorie ENUM ('1','2','3','4','5') NOT NULL,\
                    virage ENUM ('sud','est','ouest','nord') NOT NULL,\
                    prix INT(4) NOT NULL,\
                    nombrePlaces INT(5) NOT NULL);",

    "createUtilisateur": "CREATE TABLE utilisateur ( idUtilisateur INT(11) PRIMARY KEY AUTO_INCREMENT,\
                            prenom VARCHAR(20) NOT NULL,\
                            nom VARCHAR(20) NOT NULL,\
                            pseudo VARCHAR(20) NOT NULL,\
                            mail VARCHAR(60) NOT NULL,\
                            motDePasse VARCHAR(20) NOT NULL);",

    "createAdministrateur": "CREATE TABLE administrateur ( idAdministrateur INT(11) PRIMARY KEY AUTO_INCREMENT,\
                            idUtilisateur INT(11) NOT NULL,\
                            FOREIGN KEY (idUtilisateur) REFERENCES utilisateur(idUtilisateur) ON DELETE CASCADE);",

    "createAcheter": "CREATE TABLE acheter ( idPlace INT(11) NOT NULL,\
                        idUtilisateur INT(11) NOT NULL,\
                        FOREIGN KEY (idPlace) REFERENCES place(idPlace) ON DELETE CASCADE,\
                        FOREIGN KEY (idUtilisateur) REFERENCES utilisateur(idUtilisateur) ON DELETE CASCADE);",
    
    "createMatch" : "CREATE TABLE matchfoot ( idMatch INT(11) PRIMARY KEY AUTO_INCREMENT,\
                        equipe1 VARCHAR(40) NOT NULL, \
                        equipe2 VARCHAR(40) NOT NULL, \
                        dateMatch DATE NOT NULL,\
                        lieuMatch VARCHAR(50) NOT NULL );",

    "createAffecter" : "CREATE TABLE affecter ( idMatch INT(11) NOT NULL,\
                        idPlace INT(11) NOT NULL,\
                        FOREIGN KEY (idMatch) REFERENCES matchfoot(idMatch) ON DELETE CASCADE,\
                        FOREIGN KEY (idPlace) REFERENCES place(idPlace) ON DELETE CASCADE);",
    
    "insertJoueur" : "INSERT INTO `joueur` (`prenom`,`nom`,`age`,`prix`,`dateNaissance`,`poste`) VALUES ('{}','{}','{}','{}','{}','{}');",

    "insertSaison" : "INSERT INTO `saison` (`annees`,`meilleurJoueur`,`parcoursEurope`,`placeLigue`) VALUES ('{}','{}','{}','{}');",

    "insertTrophee" : "INSERT INTO `trophee` (`nomTrophee`) VALUES ('{}');",

    "insertParticiper" : "INSERT INTO `participer` (`idSaison`,`idJoueur`) VALUES ('{}','{}');",

    "insertGagner" : "INSERT INTO `gagner` (`idTrophee`,`idSaison`) VALUES ('{}','{}');",

    "insertPlace" : "INSERT INTO `place` (`nomCategorie`,`virage`,`prix`,`nombrePlaces`) VALUES ('{}','{}','{}','{}');",

    "insertUtilisateur" : "INSERT INTO `utilisateur` (`prenom`,`nom`,`pseudo`,`mail`,`motDePasse`) VALUES ('{}','{}','{}','{}','{}');",

    "insertAdministrateur" : "INSERT INTO `administrateur` (`idUtilisateur`) VALUES ('{}');",

    "insertAcheter" : "INSERT INTO `acheter` (`idPlace`,`idUtilisateur`) VALUES ('{}','{}');",

    "insertMatch" : "INSERT INTO `matchfoot` (`equipe1`,`equipe2`,`dateMatch`,`lieuMatch`) VALUES ('{}','{}','{}','{}');",

    "insertAffecter" : "INSERT INTO `affecter` (`idMatch`,`idPlace`) VALUES ('{}','{}');",

    "getAdminConnexion" : "SELECT `pseudo`, `motDePasse` FROM `administrateur` LEFT JOIN `utilisateur` USING(`idUtilisateur`);",

    "getUserConnexion" : "SELECT `pseudo`, `motDePasse` FROM `utilisateur`;",

    "getJoueurs": "SELECT * FROM `joueur`;",

    "getJoueurByID": "SELECT * FROM `joueur` WHERE `idJoueur`={};",
    
    "getSaisons": "SELECT * FROM `saison`;",

    "getSaisonByID" : "SELECT * FROM `saison` WHERE `idSaison`={};",

    "getJoueursTrancheAge": "SELECT * FROM `joueur` WHERE `age` BETWEEN {} AND {};",
    
    "getJoueursTranchePrix": "SELECT * FROM `joueur` WHERE `prix` BETWEEN {} AND {};",
    
    "getJoueursAlphabetique": "SELECT * FROM `joueur` ORDER BY `nom`, `prenom`;",
    
    "getJoueursParPrix": "SELECT * FROM `joueur` ORDER BY `prix`;",
    
    "getJoueursParPoste": "SELECT * FROM `joueur` ORDER BY `poste`;",
    
    "getSaisonsTropheesGagnes": "SELECT saison.*, COUNT(gagner.idSaison) AS nombre_trophees FROM saison LEFT JOIN gagner ON saison.idSaison = gagner.idSaison GROUP BY saison.idSaison ORDER BY nombre_trophees DESC;",

    "getSaisonsPlaceLigue": "SELECT * FROM `saison` ORDER BY `placeLigue`;",
    
    "deleteJoueur": "DELETE FROM `joueur` WHERE `idJoueur`={};",
    
    "deleteSaison": "DELETE FROM `saison` WHERE `idSaison`={};",

    "getUserInfo" : "SELECT * FROM `utilisateur` WHERE `pseudo`='{}';",

    "getUserId" : "SELECT idUtilisateur FROM `utilisateur` WHERE `pseudo`='{}';",

    "updateMotDePasse": "UPDATE `utilisateur` SET `motDePasse` = '{}' WHERE `pseudo` = '{}';",

    "mdpUser" : "SELECT `motDePasse` FROM `utilisateur` WHERE `pseudo`='{}';",

    "places" : "SELECT * FROM `place`;",

    "placeUser" : "SELECT nomCategorie,virage,prix FROM `place` JOIN `acheter` USING(`idPlace`) JOIN `utilisateur` USING(`idUtilisateur`) WHERE utilisateur.pseudo='{}';",

    "placesByCategoryAndVirage" : "SELECT * FROM `place` WHERE `nomCategorie` = '{}' AND virage = '{}';",

    "getMatch" : "SELECT * FROM `matchfoot`;",

    "getPlacesForMatch" : "SELECT place.idPlace, place.nomCategorie, place.virage, place.prix, place.nombrePlaces FROM place JOIN `affecter` USING (idPlace) WHERE `affecter.idMatch`={};",

    "getMatchByID" : "SELECT * FROM `match` WHERE idMatch = {}; ",

    "setPlaces": "UPDATE `place` SET `nombrePlaces` = `nombrePlaces` - 1 WHERE `idPlace` = {};"
    }
