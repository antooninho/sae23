import cherrypy, os
from mako.template import Template
from mako.lookup import TemplateLookup
from creationBase import *
from requetesSQL import getMatch, connexionAdmin, getPlaceUtilisateur, getPlacesByCategoryAndVirage, updateMDP, acheterPlace, getUserInfo, connexion, printSaisons, printParTropheesGagnes, printParPlaceLigue, printParTrancheAge, getPlaces, printParTranchePrix, printParAlphabetique, printParPrix, printParPoste, insertJoueur, insertSaison, delJoueur, delSaison, mdpUtilisateur
mylookup = TemplateLookup(directories=['ressources/templates'], input_encoding='utf-8', module_directory='ressources/tmp/mako_modules')

class InterfaceWeb(object):
    def __init__(self):
        self.connecte = False
        self.admin=False
        self.pseudo=""
        
    ###### Page de connexion ###########     

    @cherrypy.expose
    def index(self):
        if not self.connecte:
            mytemplate = mylookup.get_template("login.html")
            return mytemplate.render()
        else:
            mytemplate = mylookup.get_template("index.html")
            return mytemplate.render(matchs=getMatch())

    @cherrypy.expose
    def login(self, pseudo=None, mdp=None):
        message=None
        if pseudo and mdp:
            if connexionAdmin(pseudo, mdp):
                self.connecte=True
                self.admin=True
                self.pseudo=pseudo
                raise cherrypy.HTTPRedirect("/index")
            if connexion(pseudo, mdp):
                self.connecte = True
                self.pseudo = pseudo
                raise cherrypy.HTTPRedirect("/index")
            else:
                message="Veuillez renseigner les bons identifiants"
                mytemplate = mylookup.get_template("login.html")
                return mytemplate.render(message=message)

    @cherrypy.expose
    def creerCompte(self, prenom=None, nom=None, pseudo=None, mail=None, motDePasse=None):
        if prenom and nom and pseudo and mail and motDePasse:
            try:
                # Appel de la fonction insertUtilisateur avec les données soumises
                insertUtilisateur(prenom, nom, pseudo, mail, motDePasse)
                # Message de succès ou redirection vers une autre page
                message="Compte créé avec succès !"
                mytemplate = mylookup.get_template("login.html")
                return mytemplate.render(message=message)
            except Exception as e:
                # En cas d'erreur lors de l'insertion
                message="Une erreur s'est produite lors de la création du compte : {}".format(str(e))
                mytemplate = mylookup.get_template("creerCompte.html")
                return mytemplate.render(message=message)
                
        else:
            # Si les données n'ont pas été soumises, afficher le formulaire de création de compte
            mytemplate = mylookup.get_template("creerCompte.html")
            return mytemplate.render()

    @cherrypy.expose
    def deconnexion(self):
        # Déconnexion de l'utilisateur en réinitialisant les attributs de session
        self.connecte = False
        self.admin=False
        self.pseudo = ""
        message="Vous êtes déconnecté"
        mytemplate = mylookup.get_template("login.html")
        return mytemplate.render(message=message)
    

    
    ##page saison
    @cherrypy.expose
    def saison(self):
        if not self.connecte:
            mytemplate = mylookup.get_template("login.html")
            return mytemplate.render()
        else:
            mytemplate = mylookup.get_template("saison.html")
            return mytemplate.render(admin=self.admin)
        
    ##page joueurs 
    @cherrypy.expose
    def joueurs(self):
        if not self.connecte:
            mytemplate = mylookup.get_template("login.html")
            return mytemplate.render()
        else:
            mytemplate=mylookup.get_template("joueurs.html")
            return mytemplate.render(admin=self.admin)


    ###### Pages d'affichages ###########     
    ## Affichage pour saison   

    @cherrypy.expose
    def affParTrophees(self):
        if not self.connecte:
            mytemplate = mylookup.get_template("login.html")
            return mytemplate.render()
        else:
            mytemplate = mylookup.get_template("affParTrophees.html")
            return mytemplate.render(annees=printParTropheesGagnes())

    @cherrypy.expose
    def affParPlaceLigue(self):
        if not self.connecte:
            mytemplate = mylookup.get_template("login.html")
            return mytemplate.render()
        else:
            mytemplate = mylookup.get_template("affParPlaceLigue.html")
            return mytemplate.render(annees=printParPlaceLigue())
    
    ## Affichage pour joueurs
    @cherrypy.expose
    def affParTrancheAge(self, age_mini=None, age_maxi=None):
        if not self.connecte:
            mytemplate = mylookup.get_template("login.html")
            return mytemplate.render()
        else:
            age_mini = int(age_mini) if age_mini is not None else 0
            age_maxi = int(age_maxi) if age_maxi is not None else 100
            # Appeler la fonction printParTrancheAge avec les valeurs d'âge
            joueurs = printParTrancheAge(age_mini, age_maxi)
            # Rendre le template avec les données récupérées
            mytemplate = mylookup.get_template("affParTrancheAge.html")
            return mytemplate.render(joueurs=joueurs)
    
    @cherrypy.expose
    def affParTranchePrix(self, prix_mini=None, prix_maxi=None):
        if not self.connecte:
            mytemplate = mylookup.get_template("login.html")
            return mytemplate.render()
        else:
            prix_mini = int(prix_mini) if prix_mini is not None else 0
            prix_maxi = int(prix_maxi) if prix_maxi is not None else 100
            # Appeler la fonction printParTrancheAge avec les valeurs d'âge
            joueurs = printParTranchePrix(prix_mini, prix_maxi)
            # Template avec les données récupérées
            mytemplate = mylookup.get_template("affParTranchePrix.html")
            return mytemplate.render(joueurs=joueurs)
    
    @cherrypy.expose
    def affParNom(self):
        if not self.connecte:
            mytemplate = mylookup.get_template("login.html")
            return mytemplate.render()
        else:
            mytemplate = mylookup.get_template("affParNom.html")
            return mytemplate.render(joueurs=printParAlphabetique())
    
    @cherrypy.expose
    def affParPrix(self):
        if not self.connecte:
            mytemplate = mylookup.get_template("login.html")
            return mytemplate.render()
        else:
            mytemplate = mylookup.get_template("affParPrix.html")
            return mytemplate.render(joueurs=printParPrix())
        
    @cherrypy.expose
    def affParPoste(self):
        if not self.connecte:
            mytemplate = mylookup.get_template("login.html")
            return mytemplate.render()
        else:   
            mytemplate = mylookup.get_template("affParPoste.html")
            return mytemplate.render(joueurs=printParPoste())
            
    ###### Pages d'insertions ###########    

    @cherrypy.expose
    def insertionJoueur(self, prenom=None, nom=None, age=None, prix=None, dateNaissance=None, poste=None):
        if not self.connecte:
            mytemplate = mylookup.get_template("login.html")
            return mytemplate.render()
        elif not self.admin:
            mytemplate = mylookup.get_template("index.html")
            return mytemplate.render(matchs=getMatch())
        else:
            # Vérifier si des données ont été soumises
            if prenom and nom and age and prix and dateNaissance and poste:
                # Convertir les valeurs d'âge et de prix en entiers ou utiliser des valeurs par défaut si elles ne sont pas fournies
                age = int(age)
                prix = int(prix)
                
                # Appeler la fonction addJoueur avec les données saisies
                insertJoueur(prenom, nom, age, prix, dateNaissance, poste)
                
                # Message de succès si les données ont été insérées
                message = "Joueur ajouté avec succès !"
            else:
                # Pas de données soumises, pas de message de succès
                message = None
            
            # Rendre le template avec éventuellement le message de succès
            mytemplate = mylookup.get_template("insertionJoueur.html")
            return mytemplate.render(message=message)
        
    
    @cherrypy.expose
    def insertionSaison(self, annees=None, meilleurJoueur=None, parcoursEurope=None, placeLigue=None):
        if not self.connecte:
            mytemplate = mylookup.get_template("login.html")
            return mytemplate.render()
        elif not self.admin:
            mytemplate = mylookup.get_template("index.html")
            return mytemplate.render(matchs=getMatch())
        else:
            # Vérifier si des données ont été soumises
            if annees and meilleurJoueur and parcoursEurope and placeLigue:
                # Appeler la fonction insertSaison avec les données soumises
                insertSaison(annees, meilleurJoueur, parcoursEurope, placeLigue)
                
                # Message de succès si les données ont été insérées
                message = "Saison ajoutée avec succès !"
            else:
                # Pas de données soumises, pas de message de succès
                message = None
            
            # Rendre le template avec éventuellement le message de succès
            mytemplate = mylookup.get_template("insertionSaison.html")
            return mytemplate.render(message=message)

    @cherrypy.expose
    def insertionMatch(self, equipe_dom, equipe_ext, date_match, lieu):
        if not self.connecte or not self.admin:
            mytemplate = mylookup.get_template("login.html")
            return mytemplate.render(message="Accès réservé aux administrateurs.")
        else:
            try:
                # Appel la fonction pour insérer un match dans la base de données
                insertMatch(equipe_dom, equipe_ext, date_match, lieu)
                message = "Match créé avec succès."
            except Exception as e:
                message = f"Erreur lors de la création du match: {str(e)}"

            mytemplate = mylookup.get_template("billetterie.html")
            return mytemplate.render(matchs=getMatch(), admin=self.admin, message=message)



    ###### Pages de suppression ###########    

    @cherrypy.expose
    def suppressionJoueur(self, idJoueur=None):
        if not self.connecte:
            mytemplate = mylookup.get_template("login.html")
            return mytemplate.render()
        elif not self.admin:
            mytemplate = mylookup.get_template("index.html")
            return mytemplate.render(matchs=getMatch())
        else:
            message = None
            joueurs = printParAlphabetique()  # Utilisation de la fonction printParAlphabetique pour récupérer les joueurs
            if idJoueur:
                try:
                    idJoueur = int(idJoueur)
                    message = delJoueur(idJoueur)
                except ValueError:
                    message = "Veuillez entrer un ID de joueur valide."
            
            mytemplate = mylookup.get_template("suppressionJoueur.html")
            return mytemplate.render(message=message, joueurs=joueurs)

    @cherrypy.expose
    def suppressionSaison(self, idSaison=None):
        if not self.connecte:
            mytemplate = mylookup.get_template("login.html")
            return mytemplate.render()
        elif not self.admin:
            mytemplate = mylookup.get_template("index.html")
            return mytemplate.render(matchs=getMatch())
        else:
            message = None
            saisons = printSaisons()  # Utilisez votre fonction pour récupérer les saisons depuis la base de données
            if idSaison:
                try:
                    idSaison = int(idSaison)
                    message = delSaison(idSaison)  # Utilisez votre fonction de suppression de saison
                except ValueError:
                    message = "Veuillez entrer un ID de saison valide."
            
            mytemplate = mylookup.get_template("suppressionSaison.html")
            return mytemplate.render(message=message, saisons=saisons)


    ###### Page du compte ###########  

    @cherrypy.expose
    def compte(self):
        if not self.connecte:
            mytemplate = mylookup.get_template("login.html")
            return mytemplate.render()
        infosUtilisateur = getUserInfo(self.pseudo)
        places=getPlaceUtilisateur(self.pseudo)
        mytemplate = mylookup.get_template("compte.html")
        return mytemplate.render(infosUtilisateur=infosUtilisateur, places=places)


    @cherrypy.expose
    def nouvMdp(self, ancienMdp=None, nouvMdp=None, confirmerMdp=None):
        messageMdp=None
        infosUtilisateur = getUserInfo(self.pseudo)
        # Vérifier si les nouveaux mots de passe correspondent
        if nouvMdp != confirmerMdp:
            messageMdp= "Les nouveaux mots de passe ne correspondent pas."
            mytemplate = mylookup.get_template("compte.html")
            return mytemplate.render(messageMdp=messageMdp, infosUtilisateur=infosUtilisateur)
        if ancienMdp != mdpUtilisateur(self.pseudo)[0][0]:
            messageMdp= "L'ancien mot de passe de correspond pas"
            mytemplate = mylookup.get_template("compte.html")
            return mytemplate.render(messageMdp=messageMdp, infosUtilisateur=infosUtilisateur)
        try:
            updateMDP(nouvMdp, self.pseudo)
            messageMdp="Mot de passe mis à jour avec succès."
            mytemplate = mylookup.get_template("compte.html")
            return mytemplate.render(messageMdp=messageMdp, infosUtilisateur=infosUtilisateur)
        except Exception as e:
            # Si une erreur se produit, annulez les modifications et affichez un message d'erreur
            connexion.rollback()
            return "Erreur lors de la mise à jour du mot de passe : " + str(e)
        
    ###### Pages de la billeterie ###########  

    @cherrypy.expose
    def billetterie(self):
        if not self.connecte:
            mytemplate = mylookup.get_template("login.html")
            return mytemplate.render()
        else:
            mytemplate = mylookup.get_template("billetterie.html")
            return mytemplate.render(matchs=getMatch(), admin=self.admin)

    
    @cherrypy.expose
    def match(self, categorie=None, virage=None, ):
        
        if not self.connecte:
            mytemplate = mylookup.get_template("login.html")
            return mytemplate.render()
        places = None
        if categorie and virage:
            places = getPlacesByCategoryAndVirage(categorie, virage)
        mytemplate = mylookup.get_template("match.html")
        return mytemplate.render(places=places)
    
    @cherrypy.expose
    def acheter(self, idPlace):
        message=""
        if not self.connecte:
            mytemplate = mylookup.get_template("login.html")
            return mytemplate.render()
        else: 
            acheterPlace(self.pseudo, idPlace)
            
            mytemplate = mylookup.get_template("match.html")
            message="Félicitations pour votre achat ! A bientôt au stade !"
            return mytemplate.render(message=message)

            
        
if __name__ == '__main__':
    rootPath = os.path.abspath(os.getcwd())
    print(f"la racine du site est :\n\t{rootPath}\n\tcontient : {os.listdir()}")
    cherrypy.quickstart(InterfaceWeb(), '/', 'config.txt')
