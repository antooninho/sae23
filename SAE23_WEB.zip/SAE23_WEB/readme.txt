Lancer l'appli :
Créer la base en lançant le fichier "creationBase.py", le fichier s'occupera de créer la base et d'insérer les données
Lancer l'application avec "interfaceWEB.py"
Le port de base est 8040 mais vous pouvez le changer via le fichier config.txt

Etat de l'application :
Il faut d'abord se connecter au compte : 
Partie admin : 
login : admin
mdp : admin
Partie CRUD
L'administrateur peut ajouter/supprimer des joueurs/saisons et ajouter un match
Le nombre de places pour le match est le même pour tous les matchs.

Partie publique :
Partie CRUD
Possibilité d'acheter une place, et de la voir affiché dans la page "mon compte"

Modification :
Ajout des tables "Match" et "Affecter" qui permettent de créer plusieurs matchs différents afin que l'admin crée un nouveau match pour l'utilisateur

Fonctionnalités prévues non réalisées : 
Affecter un nombre de place par virage différent pour chaque match,
Supprimer un match

Contenu : 
L'archive contient des fichiers HTML pour les différentes pages du site, un fichier CSS pour les styles, 
des scripts JavaScript et Python pour la logique et la gestion des requêtes, ainsi qu'un fichier CSV pour les données de base. Les scripts Python incluent 
la création de la base de données et l'interface web. Un fichier de configuration et un README sont également inclus pour guider l'utilisation du projet.