from requetes import _requete
import csv, os, pymysql
import random

_dbConfig = {
        'driver' : "MySQL",
        'db' : 'OMStats',
        'host' : "localhost",
        'user' : "admin",
        'passwd' : "admin",
        'port' : 3306
    }


def dbConnect():
    db = pymysql.connect(host = _dbConfig['host'], user=_dbConfig['user'], passwd=_dbConfig['passwd'], port=int(_dbConfig['port']), db = _dbConfig['db'])
    cursor=db.cursor()
    return (db,db.cursor())

def creation_base():
    db = pymysql.connect(host = _dbConfig['host'], user=_dbConfig['user'], passwd=_dbConfig['passwd'], port=int(_dbConfig['port']))
    cursor = db.cursor()
    cursor.execute(_requete["drop"])
    cursor.execute(_requete["createBase"])
    cursor.execute(_requete["use"])
    cursor.execute(_requete["createJoueur"])
    cursor.execute(_requete["createSaison"])
    cursor.execute(_requete["createTrophee"])
    cursor.execute(_requete["createParticiper"])
    cursor.execute(_requete["createGagner"])
    cursor.execute(_requete["createPlace"])
    cursor.execute(_requete["createUtilisateur"])
    cursor.execute(_requete["createAdministrateur"])
    cursor.execute(_requete["createAcheter"])
    cursor.execute(_requete["createMatch"])
    cursor.execute(_requete["createAffecter"])
    


def insertJoueur(prenom : str, nom : str, age : int, prix : int, dateNaissance : str, poste : str) -> str:
    requete= _requete["insertJoueur"].format(prenom,nom,age,prix,dateNaissance,poste)
    execute(requete)

def insertSaison(annees : str, meilleurJoueur : str, parcoursEurope : str, placeLigue : str) -> str:
    requete= _requete["insertSaison"].format(annees,meilleurJoueur,parcoursEurope,placeLigue)
    execute(requete)

def insertTrophee(nomTrophee : str) -> str:
    requete= _requete["insertTrophee"].format(nomTrophee)
    execute(requete)

def insertParticiper(idSaison : int, idJoueur : int) -> str:
    requete= _requete["insertParticiper"].format(idSaison, idJoueur)
    execute(requete)

def insertGagner(idTrophee : int, idSaison : int) -> str:
    requete= _requete["insertGagner"].format(idTrophee, idSaison)
    execute(requete)

def insertPlace(nomCategorie : str, virage : str, prix : int, nombrePlaces : int) -> str:
    requete= _requete["insertPlace"].format(nomCategorie,virage,prix,nombrePlaces)
    execute(requete)

def insertUtilisateur(prenom : str, nom : str, pseudo : str, mail : str, motDePasse : str ) -> str:
    requete= _requete["insertUtilisateur"].format(prenom,nom,pseudo,mail,motDePasse)
    execute(requete)

def insertAdministrateur(idUtilisateur : int):
    requete= _requete["insertAdministrateur"].format(idUtilisateur)
    execute(requete)

def insertAcheter(idPlace : str, idUtilisateur : str):
    requete= _requete["insertAcheter"].format(idPlace, idUtilisateur)
    execute(requete)

def insertMatch(match1 : str, match2 : str, date : str, lieu : str):
    requete=_requete["insertMatch"].format(match1, match2, date, lieu)
    execute(requete)

def insertAffecter(idMatch : int, idPlace : int):
    requete=_requete["insertAffecter"].format(idMatch, idPlace)
    execute(requete)

def insertPlaceRandom(idMatch: int):
    virages = ["sud", "nord", "est", "ouest"]
    
    for virage in virages:
        for categorie in range(1, 6):  # Les catégories vont de 1 à 5
            prix = random.randint(20, 100)  # Générer un prix aléatoire entre 20 et 100
            nombrePlaces = random.randint(50, 200)  # Générer un nombre de places aléatoire entre 50 et 200
            
            # Insérer les places dans la table Place
            idPlace = insertPlace((str(categorie), virage, prix, nombrePlaces))
            
            # Lier les places au match
            insertAffecter((idMatch, idPlace))

def execute(req : str) :    
    _dbEtudiant, _cursorEtudiant = dbConnect()
    res = _cursorEtudiant.execute(req)
    if "SELECT" in req :
        res = _cursorEtudiant.fetchall()
    else :
        _dbEtudiant.commit()
    return res

def date_format(date : str ) -> str :
    """ fonction de conversion d'une date-chaîne au format "habituel" (jj/mm/aa)
            au format (aaaa-mm-jj)
    """
    d = date.split('/')
    if int(d[2]) > 26 :
        d[2]="19"+d[2]
    elif int(d[2]) <=26  :
        d[2]="20"+d[2]
    s = d[2]+"-"+ d[1]+"-"+d[0]
    return s

def chargement_donnees(chemin : str) -> None:
    table=0
    with open(chemin, newline='',encoding='utf-8') as fichier_csv :
        lignes=csv.reader(fichier_csv, delimiter=",")
        for champ in lignes:
            print(champ)
            if champ[0]==",":
                print(len(champ))
                print("table suivante")
                table=table+1
            if champ[0]!=",":
                if table==0:
                    prenom=champ[1].capitalize()
                    nom=champ[2].capitalize()
                    age=champ[3]
                    prix=champ[4]
                    dateNaissance=date_format(champ[5])
                    poste=champ[6].lower()
                    insertJoueur(prenom,nom,int(age),int(prix),dateNaissance,poste)
                elif table==1:
                    annees=champ[1]
                    meilleurJoueur=champ[2].capitalize()
                    parcoursEurope=champ[3]
                    placeLigue=champ[4]
                    insertSaison(annees,meilleurJoueur,parcoursEurope,int(placeLigue))
                elif table==2:
                    nomTrophee=champ[1]
                    insertTrophee(nomTrophee)
                elif table==3:
                    idSaison=champ[0]
                    idJoueur=champ[1]
                    insertParticiper(int(idSaison),int(idJoueur))
                elif table==4:
                    idTrophee=champ[0]
                    idSaison=champ[1]
                    insertGagner(int(idTrophee),int(idSaison))
                elif table==5:
                    nomCategorie=champ[1]
                    virage=champ[2]
                    prix=champ[3]
                    nombrePlaces=champ[4]
                    insertPlace(nomCategorie,virage,int(prix),int(nombrePlaces))
                elif table==6:
                    prenom=champ[1]
                    nom=champ[2]
                    pseudo=champ[3]
                    mail=champ[4]
                    motDePasse=champ[5]
                    insertUtilisateur(prenom,nom,pseudo,mail,motDePasse)
                elif table==7:
                    idUtilisateur=champ[1]
                    insertAdministrateur(idUtilisateur)
                elif table==8:
                    idPlace=champ[0]
                    idUtilisateur=champ[1]
                    insertAcheter(idPlace,idUtilisateur)
                elif table==9:
                    match1=champ[0]
                    match2=champ[1]
                    date=date_format(champ[2])
                    lieu=champ[3]
                    insertMatch(match1, match2, date, lieu)
                elif table==10:
                    idMatch=champ[0]
                    idPlace=champ[1]
                    insertAffecter(idMatch, idPlace)
                else:
                    return "Base créée et remplie"

if __name__ == '__main__':
    creation_base()   
    print(chargement_donnees('./donneesBase.csv'))
