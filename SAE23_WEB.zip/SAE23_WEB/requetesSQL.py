from requetes import _requete
from creationBase import execute

def affichagePrix(prix):
    if prix >= 1000000:
        return "{:,.1f} MILLIONS".format(prix / 1000000)
    elif prix >= 1000:
        return "{:,.0f} MILLE".format(prix / 1000)
    elif prix==1:
        return "prix inconnu"
    elif prix==0:
        return "gratuit"
    else:
        return "{:,.0f}".format(prix)


def printParTropheesGagnes():
    requete=_requete["getSaisonsTropheesGagnes"]
    infosSaison=execute(requete)
    return infosSaison

def printParPlaceLigue():
    requete=_requete["getSaisonsPlaceLigue"]
    infosSaison=execute(requete)
    return infosSaison

def printParTrancheAge(ageMini,ageMaxi):
    requete=_requete["getJoueursTrancheAge"].format(ageMini,ageMaxi)
    joueurs=execute(requete)
    return joueurs_avec_prix(joueurs)

def printParTranchePrix(prixMini, prixMaxi):
    requete=_requete["getJoueursTranchePrix"].format(prixMini,prixMaxi)
    joueurs=execute(requete)
    return joueurs_avec_prix(joueurs)

def printParAlphabetique():
    requete=_requete["getJoueursAlphabetique"]
    joueurs=execute(requete)
    return joueurs_avec_prix(joueurs)

def joueurs_avec_prix(joueurs : tuple):
    joueurs_prix = [(joueur[0], joueur[1], joueur[2], joueur[3], affichagePrix(joueur[4]), joueur[5], joueur[6]) for joueur in joueurs]
    return joueurs_prix

def printParPrix():
    requete=_requete["getJoueursParPrix"]
    joueurs=execute(requete)
    return joueurs_avec_prix(joueurs)

def printParPoste():
    requete=_requete["getJoueursParPoste"]
    joueurs=execute(requete)
    return joueurs_avec_prix(joueurs)

def insertJoueur(prenom : str, nom : str, age : int, prix : int, dateNaissance : str, poste : str):
    requete= _requete["insertJoueur"].format(prenom,nom,age,prix,dateNaissance,poste)
    execute(requete)

def insertSaison(annees : str, meilleurJoueur : str, parcoursEurope : str, placeLigue : str) -> str:
    requete= _requete["insertSaison"].format(annees,meilleurJoueur,parcoursEurope,placeLigue)
    execute(requete)

def printSaisons():
    requeteSaison=_requete["getSaisons"]
    saisons=execute(requeteSaison)
    return saisons

def delJoueur(idJoueur):
    try:
        requeteJoueurID = _requete["getJoueurByID"].format(idJoueur)
        joueurID = execute(requeteJoueurID)
        # Vérifier si un joueur avec cet ID existe
        if joueurID:
            delRequete = _requete["deleteJoueur"].format(idJoueur)
            execute(delRequete)
            return "Suppression effectuée avec succès"
        else:
            return "Aucun joueur trouvé avec ce nom"
    except ValueError:
        return "*** Entrez un entier s'il vous plaît"

def delSaison(idSaison):
    try:
        requeteSaisonID = _requete["getSaisonByID"].format(idSaison)
        saisonID = execute(requeteSaisonID)
        
        if not saisonID:
            return "La saison spécifiée n'existe pas dans la base de données."
        
        delRequete = _requete["deleteSaison"].format(idSaison)
        execute(delRequete)
        
        return "Suppression de la saison effectuée avec succès."
    except ValueError:
        return "Veuillez entrer un ID de saison valide."

def connexion(pseudo, mdp):
    requete=_requete["getUserConnexion"]
    infoConnexion=execute(requete)
    for info in infoConnexion: 
        if pseudo==info[0] and mdp==info[1]:
            return True
    return False

def connexionAdmin(pseudo, mdp):
    requete=_requete["getAdminConnexion"]
    infoConnexion=execute(requete)
    for info in infoConnexion: 
        if pseudo==info[0] and mdp==info[1]:
            return True
    return False

def getUserInfo(pseudo):
    requete=_requete["getUserInfo"].format(pseudo)
    infosUtilisateur=execute(requete)
    return infosUtilisateur

def updateMDP(nvMdp, pseudo):
    requete=_requete["updateMotDePasse"].format(nvMdp, pseudo)
    execute(requete)

def mdpUtilisateur(pseudo):
    requete=_requete["mdpUser"].format(pseudo)
    mdp=execute(requete)
    return mdp

def acheterPlace(pseudo, idPlace):
    try:
        idUser = getUserId(pseudo)
        requete = _requete["insertAcheter"].format(idPlace, idUser)
        execute(requete)
        requete = _requete["setPlaces"].format(idPlace)
        execute(requete)
    except ValueError as e:
        return str(e)

def getUserId(pseudo) -> int:
    requete = _requete["getUserId"].format(pseudo)
    userId = execute(requete)
    if not userId:
        raise ValueError(f"Utilisateur avec le pseudo '{pseudo}' non trouvé")
    return userId[0][0]

def getPlaces():
    requete=_requete["places"]
    place=execute(requete)
    return place

def getPlaceUtilisateur(pseudo):
    requete=_requete["placeUser"].format(pseudo)
    place=execute(requete)
    return place

def getPlacesByCategoryAndVirage(categorie, virage):
    requete=_requete["placesByCategoryAndVirage"].format(categorie, virage)
    places = execute(requete)
    return places

def getMatch():
    requete=_requete["getMatch"]
    matchs=execute(requete)
    return matchs

def getPlacesForMatch(idMatch):
    requete=_requete["getPlacesForMatch"].format(idMatch)
    places=execute(requete)
    return places

def getMatchByID(idMatch):
    requete=_requete["getMatchByID"].format(idMatch)
    places=execute(requete)
    return places

