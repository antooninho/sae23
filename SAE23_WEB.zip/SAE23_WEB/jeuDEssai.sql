-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : dim. 26 mai 2024 à 10:46
-- Version du serveur : 10.4.32-MariaDB
-- Version de PHP : 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `omstats`
--

-- --------------------------------------------------------

--
-- Structure de la table `acheter`
--

CREATE TABLE `acheter` (
  `idPlace` int(11) NOT NULL,
  `idUtilisateur` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Déchargement des données de la table `acheter`
--

INSERT INTO `acheter` (`idPlace`, `idUtilisateur`) VALUES
(1, 2);

-- --------------------------------------------------------

--
-- Structure de la table `administrateur`
--

CREATE TABLE `administrateur` (
  `idAdministrateur` int(11) NOT NULL,
  `idUtilisateur` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Déchargement des données de la table `administrateur`
--

INSERT INTO `administrateur` (`idAdministrateur`, `idUtilisateur`) VALUES
(1, 1);

-- --------------------------------------------------------

--
-- Structure de la table `affecter`
--

CREATE TABLE `affecter` (
  `idMatch` int(11) NOT NULL,
  `idPlace` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Déchargement des données de la table `affecter`
--

INSERT INTO `affecter` (`idMatch`, `idPlace`) VALUES
(1, 1),
(1, 2),
(1, 3),
(1, 4),
(1, 5),
(1, 6),
(1, 7),
(1, 8),
(1, 9),
(1, 10),
(1, 11),
(1, 12),
(1, 13),
(1, 14),
(1, 15),
(1, 16),
(1, 17),
(1, 18),
(1, 19),
(1, 20);

-- --------------------------------------------------------

--
-- Structure de la table `gagner`
--

CREATE TABLE `gagner` (
  `idTrophee` int(11) NOT NULL,
  `idSaison` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Déchargement des données de la table `gagner`
--

INSERT INTO `gagner` (`idTrophee`, `idSaison`) VALUES
(1, 7),
(2, 12),
(2, 13),
(2, 14),
(3, 3),
(4, 3),
(4, 4),
(4, 5),
(4, 6),
(4, 7),
(4, 12),
(5, 11),
(6, 13),
(6, 14);

-- --------------------------------------------------------

--
-- Structure de la table `joueur`
--

CREATE TABLE `joueur` (
  `idJoueur` int(11) NOT NULL,
  `prenom` varchar(20) NOT NULL,
  `nom` varchar(20) NOT NULL,
  `age` int(3) NOT NULL,
  `prix` int(10) NOT NULL,
  `dateNaissance` date NOT NULL,
  `poste` enum('défenseur','gardien','milieu','attaquant') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Déchargement des données de la table `joueur`
--

INSERT INTO `joueur` (`idJoueur`, `prenom`, `nom`, `age`, `prix`, `dateNaissance`, `poste`) VALUES
(1, 'Roger', 'Magnusson', 79, 1, '1945-03-20', 'attaquant'),
(2, 'Didier', 'Drogba', 46, 6000000, '1978-03-11', 'attaquant'),
(3, 'Josip ', 'Skoblar', 83, 1, '1941-03-12', 'attaquant'),
(4, 'Eric', 'Di meco', 60, 0, '1963-09-07', 'défenseur'),
(5, 'Basile', 'Boli', 57, 0, '1967-01-02', 'défenseur'),
(6, 'Chris', 'Waddle', 63, 5400000, '1960-12-14', 'milieu'),
(7, 'Fabien', 'Barthez', 52, 0, '1971-06-28', 'gardien'),
(8, 'Steve', 'Mandanda', 39, 2500000, '1985-03-28', 'gardien'),
(9, 'Didier', 'Deschamps', 55, 510000, '1968-10-15', 'milieu'),
(10, 'Mamadou', 'Niang', 44, 7000000, '1979-10-13', 'attaquant'),
(11, 'Dimitri', 'Payet', 37, 29300000, '1987-03-29', 'milieu'),
(12, 'Lucho', 'Gonzàlez', 43, 19000000, '1981-01-19', 'milieu'),
(13, 'Djibril', 'Cissé', 42, 9000000, '1981-08-12', 'attaquant'),
(14, 'Marcel', 'Desailly', 55, 1, '1968-09-07', 'défenseur'),
(15, 'Matteo', 'Guendouzi', 25, 11000000, '1999-04-14', 'milieu'),
(16, 'Pierre-emerick', 'Aubameyang', 34, 0, '1989-06-18', 'attaquant'),
(17, 'Alexis', 'Sánchez', 35, 0, '1988-12-19', 'attaquant'),
(18, 'Jordan', 'Veretout', 31, 12450000, '1993-03-01', 'milieu'),
(19, 'Jonathan', 'Clauss', 31, 7500000, '1992-09-25', 'défenseur'),
(20, 'Jean-pierre', 'Papin', 60, 1800000, '1963-11-05', 'attaquant'),
(21, 'Rudi', 'Völler', 64, 1, '1960-04-13', 'attaquant');

-- --------------------------------------------------------

--
-- Structure de la table `matchfoot`
--

CREATE TABLE `matchfoot` (
  `idMatch` int(11) NOT NULL,
  `equipe1` varchar(40) NOT NULL,
  `equipe2` varchar(40) NOT NULL,
  `dateMatch` date NOT NULL,
  `lieuMatch` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Déchargement des données de la table `matchfoot`
--

INSERT INTO `matchfoot` (`idMatch`, `equipe1`, `equipe2`, `dateMatch`, `lieuMatch`) VALUES
(1, 'Olympique de Marseille', 'Paris-Saint-Germain', '2024-06-15', 'Stade Vélodrome');

-- --------------------------------------------------------

--
-- Structure de la table `participer`
--

CREATE TABLE `participer` (
  `idSaison` int(11) NOT NULL,
  `idJoueur` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Déchargement des données de la table `participer`
--

INSERT INTO `participer` (`idSaison`, `idJoueur`) VALUES
(10, 2),
(1, 4),
(3, 4),
(4, 4),
(5, 4),
(6, 4),
(7, 4),
(5, 5),
(6, 5),
(7, 5),
(4, 6),
(5, 6),
(6, 6),
(7, 7),
(10, 7),
(12, 8),
(13, 8),
(14, 8),
(15, 8),
(16, 8),
(4, 9),
(6, 9),
(7, 9),
(11, 10),
(12, 10),
(15, 11),
(16, 11),
(17, 11),
(12, 12),
(13, 12),
(7, 14),
(16, 15),
(17, 15),
(17, 17),
(17, 18),
(17, 19),
(1, 20),
(2, 20),
(3, 20),
(4, 20),
(5, 20),
(6, 20),
(7, 21);

-- --------------------------------------------------------

--
-- Structure de la table `place`
--

CREATE TABLE `place` (
  `idPlace` int(11) NOT NULL,
  `nomCategorie` enum('1','2','3','4','5') NOT NULL,
  `virage` enum('sud','est','ouest','nord') NOT NULL,
  `prix` int(4) NOT NULL,
  `nombrePlaces` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Déchargement des données de la table `place`
--

INSERT INTO `place` (`idPlace`, `nomCategorie`, `virage`, `prix`, `nombrePlaces`) VALUES
(1, '1', 'sud', 129, 2456),
(2, '1', 'est', 129, 1857),
(3, '1', 'ouest', 129, 123),
(4, '1', 'nord', 129, 0),
(5, '2', 'sud', 89, 3021),
(6, '2', 'est', 89, 3124),
(7, '2', 'ouest', 89, 35),
(8, '2', 'nord', 89, 940),
(9, '3', 'sud', 69, 0),
(10, '3', 'est', 69, 456),
(11, '3', 'ouest', 69, 1364),
(12, '3', 'nord', 69, 1993),
(13, '4', 'sud', 49, 94),
(14, '4', 'est', 49, 2684),
(15, '4', 'ouest', 49, 494),
(16, '4', 'nord', 49, 44),
(17, '5', 'sud', 29, 3201),
(18, '5', 'est', 29, 0),
(19, '5', 'ouest', 29, 543),
(20, '5', 'nord', 29, 789);

-- --------------------------------------------------------

--
-- Structure de la table `saison`
--

CREATE TABLE `saison` (
  `idSaison` int(11) NOT NULL,
  `annees` varchar(9) NOT NULL,
  `meilleurJoueur` varchar(40) NOT NULL,
  `parcoursEurope` varchar(60) NOT NULL,
  `placeLigue` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Déchargement des données de la table `saison`
--

INSERT INTO `saison` (`idSaison`, `annees`, `meilleurJoueur`, `parcoursEurope`, `placeLigue`) VALUES
(1, '1986-1987', 'Jean-pierre papin', 'pas qualifié', 2),
(2, '1987-1988', 'Jean-pierre papin', 'Demi-Finaliste de la Coupe des Coupes', 6),
(3, '1988-1989', 'Jean-pierre papin', 'pas qualifié', 1),
(4, '1989-1990', 'Jean-pierre papin', 'Demi-Finaliste de la Coupe des clubs champions', 1),
(5, '1990-1991', 'Jean-pierre papin', 'Finaliste de la Coupe des clubs champions', 1),
(6, '1991-1992', 'Jean-pierre papin', 'Huitièmes de finale de la Coupe des clubs champions', 1),
(7, '1992-1993', 'Alen bokšić', 'Vainqueur de la Ligue des champions', 1),
(8, '1998-1999', 'Laurent blanc', 'Finaliste de la Coupe UEFA', 2),
(9, '2002-2003', 'Daniel van buyten', 'pas qualifié', 3),
(10, '2003-2004', 'Didier drogba', 'Finaliste de la Coupe UEFA', 7),
(11, '2005-2006', 'Franck ribéry', 'Vainqueur de la Coupe Intertoto/8èmes de finale de la Coupe ', 5),
(12, '2009-2010', 'Mamadou niang', 'Huitièmes de finale de la Ligue Europa', 1),
(13, '2010-2011', 'André ayew', 'Huitièmes de finale de la Ligue des champions', 2),
(14, '2011-2012', 'André ayew', 'Quarts de finaliste de la Ligue des champions', 10),
(15, '2017-2018', 'Dimitri payet', 'Finaliste de la Ligue Europa', 4),
(16, '2021-2022', 'Dimitri payet', 'Demi-Finaliste de la Ligue Europa Conférence', 2),
(17, '2022-2023', 'Alexis sánchez', 'Quatrième du groupe en Ligue des champions', 3);

-- --------------------------------------------------------

--
-- Structure de la table `trophee`
--

CREATE TABLE `trophee` (
  `idTrophee` int(11) NOT NULL,
  `nomTrophee` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Déchargement des données de la table `trophee`
--

INSERT INTO `trophee` (`idTrophee`, `nomTrophee`) VALUES
(1, 'Ligue des champions'),
(2, 'Coupe de la Ligue'),
(3, 'Coupe de France'),
(4, 'Ligue 1'),
(5, 'Coupe Intertoto'),
(6, 'Trophée des champions');

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

CREATE TABLE `utilisateur` (
  `idUtilisateur` int(11) NOT NULL,
  `prenom` varchar(20) NOT NULL,
  `nom` varchar(20) NOT NULL,
  `pseudo` varchar(20) NOT NULL,
  `mail` varchar(60) NOT NULL,
  `motDePasse` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Déchargement des données de la table `utilisateur`
--

INSERT INTO `utilisateur` (`idUtilisateur`, `prenom`, `nom`, `pseudo`, `mail`, `motDePasse`) VALUES
(1, 'admin', 'admin', 'admin', 'admin@outlook.com', 'admin'),
(2, 'Antonin', 'Mottet', 'mottetan', 'mail@outlook.com', 'mottetan');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `acheter`
--
ALTER TABLE `acheter`
  ADD KEY `idPlace` (`idPlace`),
  ADD KEY `idUtilisateur` (`idUtilisateur`);

--
-- Index pour la table `administrateur`
--
ALTER TABLE `administrateur`
  ADD PRIMARY KEY (`idAdministrateur`),
  ADD KEY `idUtilisateur` (`idUtilisateur`);

--
-- Index pour la table `affecter`
--
ALTER TABLE `affecter`
  ADD KEY `idMatch` (`idMatch`),
  ADD KEY `idPlace` (`idPlace`);

--
-- Index pour la table `gagner`
--
ALTER TABLE `gagner`
  ADD KEY `idTrophee` (`idTrophee`),
  ADD KEY `idSaison` (`idSaison`);

--
-- Index pour la table `joueur`
--
ALTER TABLE `joueur`
  ADD PRIMARY KEY (`idJoueur`);

--
-- Index pour la table `matchfoot`
--
ALTER TABLE `matchfoot`
  ADD PRIMARY KEY (`idMatch`);

--
-- Index pour la table `participer`
--
ALTER TABLE `participer`
  ADD KEY `idSaison` (`idSaison`),
  ADD KEY `idJoueur` (`idJoueur`);

--
-- Index pour la table `place`
--
ALTER TABLE `place`
  ADD PRIMARY KEY (`idPlace`);

--
-- Index pour la table `saison`
--
ALTER TABLE `saison`
  ADD PRIMARY KEY (`idSaison`);

--
-- Index pour la table `trophee`
--
ALTER TABLE `trophee`
  ADD PRIMARY KEY (`idTrophee`);

--
-- Index pour la table `utilisateur`
--
ALTER TABLE `utilisateur`
  ADD PRIMARY KEY (`idUtilisateur`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `administrateur`
--
ALTER TABLE `administrateur`
  MODIFY `idAdministrateur` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `joueur`
--
ALTER TABLE `joueur`
  MODIFY `idJoueur` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT pour la table `matchfoot`
--
ALTER TABLE `matchfoot`
  MODIFY `idMatch` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `place`
--
ALTER TABLE `place`
  MODIFY `idPlace` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT pour la table `saison`
--
ALTER TABLE `saison`
  MODIFY `idSaison` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT pour la table `trophee`
--
ALTER TABLE `trophee`
  MODIFY `idTrophee` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT pour la table `utilisateur`
--
ALTER TABLE `utilisateur`
  MODIFY `idUtilisateur` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `acheter`
--
ALTER TABLE `acheter`
  ADD CONSTRAINT `acheter_ibfk_1` FOREIGN KEY (`idPlace`) REFERENCES `place` (`idPlace`) ON DELETE CASCADE,
  ADD CONSTRAINT `acheter_ibfk_2` FOREIGN KEY (`idUtilisateur`) REFERENCES `utilisateur` (`idUtilisateur`) ON DELETE CASCADE;

--
-- Contraintes pour la table `administrateur`
--
ALTER TABLE `administrateur`
  ADD CONSTRAINT `administrateur_ibfk_1` FOREIGN KEY (`idUtilisateur`) REFERENCES `utilisateur` (`idUtilisateur`) ON DELETE CASCADE;

--
-- Contraintes pour la table `affecter`
--
ALTER TABLE `affecter`
  ADD CONSTRAINT `affecter_ibfk_1` FOREIGN KEY (`idMatch`) REFERENCES `matchfoot` (`idMatch`) ON DELETE CASCADE,
  ADD CONSTRAINT `affecter_ibfk_2` FOREIGN KEY (`idPlace`) REFERENCES `place` (`idPlace`) ON DELETE CASCADE;

--
-- Contraintes pour la table `gagner`
--
ALTER TABLE `gagner`
  ADD CONSTRAINT `gagner_ibfk_1` FOREIGN KEY (`idTrophee`) REFERENCES `trophee` (`idTrophee`) ON DELETE CASCADE,
  ADD CONSTRAINT `gagner_ibfk_2` FOREIGN KEY (`idSaison`) REFERENCES `saison` (`idSaison`) ON DELETE CASCADE;

--
-- Contraintes pour la table `participer`
--
ALTER TABLE `participer`
  ADD CONSTRAINT `participer_ibfk_1` FOREIGN KEY (`idSaison`) REFERENCES `saison` (`idSaison`) ON DELETE CASCADE,
  ADD CONSTRAINT `participer_ibfk_2` FOREIGN KEY (`idJoueur`) REFERENCES `joueur` (`idJoueur`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
